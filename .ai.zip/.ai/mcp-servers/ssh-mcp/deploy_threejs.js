import {Client} from 'ssh2';
import dotenv from 'dotenv';

dotenv.config(); // Should pick up .env in the same folder (.agents/ssh-mcp)

const conn = new Client();
conn.on('ready', () => {
    console.log('SSH Ready');
    const domain = 'algo.stagings.website';
    const containerName = 'three-js-algo';
    const network = 'coolify';
    const volumePath = '/home/santosyoraciones/htdocs/santosyoraciones.com/three-js-site';
    
    // Using simple quotes for rule and backticks for host inside the shell
    const command = `docker stop ${containerName} || true && \
                     docker rm ${containerName} || true && \
                     docker run -d --name ${containerName} --network ${network} \
                     -v ${volumePath}:/usr/share/nginx/html \
                     -l traefik.enable=true \
                     -l "traefik.http.routers.threejs.rule=Host(\`${domain}\`)" \
                     -l traefik.http.routers.threejs.entrypoints=http \
                     -l traefik.http.services.threejs.loadbalancer.server.port=80 \
                     nginx:alpine`;
    
    conn.exec(command, (err, stream) => {
        if (err) throw err;
        stream.on('close', (code, signal) => {
            console.log('Command finished with code ' + code);
            conn.end();
        }).on('data', (data) => {
            console.log('STDOUT: ' + data);
        }).stderr.on('data', (data) => {
            console.log('STDERR: ' + data);
        });
    });
}).on('error', (err) => {
    console.error('SSH Error:', err);
}).connect({
    host: process.env.SSH_HOST,
    port: parseInt(process.env.SSH_PORT),
    username: process.env.SSH_USER,
    password: process.env.SSH_PASSWORD
});
