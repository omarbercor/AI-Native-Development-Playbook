import {Client} from 'ssh2';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

// Current directory is .agents/ssh-mcp
dotenv.config();

const conn = new Client();
conn.on('ready', () => {
    console.log('SSH Ready');
    conn.sftp((err, sftp) => {
        if (err) throw err;
        const files = ['index.html', 'style.css', 'main.js'];
        const remotePath = 'htdocs/santosyoraciones.com/three-js-site';
        
        // Use full path to find the files in ../../three-site
        const localBasePath = path.join(process.cwd(), '../../three-site');

        sftp.mkdir(remotePath, (err) => {
            let completed = 0;
            files.forEach(file => {
                const localFilePath = path.join(localBasePath, file);
                const remoteFilePath = remotePath + '/' + file;
                const localData = fs.readFileSync(localFilePath);
                
                sftp.writeFile(remoteFilePath, localData, (err) => {
                    if (err) {
                        console.error('Error uploading ' + file + ':', err);
                    } else {
                        console.log('Uploaded: ' + file);
                    }
                    completed++;
                    if (completed === files.length) {
                        conn.end();
                    }
                });
            });
        });
    });
}).on('error', (err) => {
    console.error('SSH Error:', err);
}).connect({
    host: process.env.SSH_HOST,
    port: parseInt(process.env.SSH_PORT),
    username: process.env.SSH_USER,
    password: process.env.SSH_PASSWORD
});
