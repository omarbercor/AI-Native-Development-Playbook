import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ErrorCode,
  ListToolsRequestSchema,
  McpError,
} from "@modelcontextprotocol/sdk/types.js";
import { Client } from "ssh2";
import dotenv from "dotenv";

dotenv.config();

const server = new Server(
  {
    name: "ssh-remote-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

const sshConfig = {
  host: process.env.SSH_HOST,
  port: parseInt(process.env.SSH_PORT || "22"),
  username: process.env.SSH_USER,
  password: process.env.SSH_PASSWORD,
};

function runSshCommand(command) {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    conn.on("ready", () => {
      conn.exec(command, (err, stream) => {
        if (err) {
            conn.end();
            return reject(err);
        }
        let stdout = "";
        let stderr = "";
        stream.on("close", (code, signal) => {
          conn.end();
          resolve({ stdout, stderr, code });
        }).on("data", (data) => {
          stdout += data.toString();
        }).stderr.on("data", (data) => {
          stderr += data.toString();
        });
      });
    }).on("error", (err) => {
      reject(err);
    }).connect(sshConfig);
  });
}

server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "ssh_exec",
        description: "Run a shell command on the remote server",
        inputSchema: {
          type: "object",
          properties: {
            command: { type: "string", description: "The command to run" },
          },
          required: ["command"],
        },
      },
      {
        name: "ssh_read_file",
        description: "Read a file from the remote server",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Absolute path to the file" },
          },
          required: ["path"],
        },
      },
      {
        name: "ssh_write_file",
        description: "Write content to a file on the remote server",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Absolute path to the file" },
            content: { type: "string", description: "Content to write" },
          },
          required: ["path", "content"],
        },
      },
      {
        name: "ssh_list",
        description: "List directory contents on the remote server",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Absolute path to the directory" },
          },
          required: ["path"],
        },
      },
    ],
  };
});

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      case "ssh_exec": {
        const result = await runSshCommand(args.command);
        return {
          content: [
            {
              type: "text",
              text: `STDOUT:\n${result.stdout}\nSTDERR:\n${result.stderr}\nCode: ${result.code}`,
            },
          ],
        };
      }
      case "ssh_read_file": {
        const result = await runSshCommand(`cat "${args.path}"`);
        if (result.code !== 0) {
            return {
                isError: true,
                content: [{ type: "text", text: result.stderr }],
            };
        }
        return {
          content: [{ type: "text", text: result.stdout }],
        };
      }
      case "ssh_write_file": {
        // Simple write using printf to handle contents safely
        const escapedContent = args.content.replace(/'/g, "'\\''");
        const result = await runSshCommand(`printf '%s' '${escapedContent}' > "${args.path}"`);
        if (result.code !== 0) {
            return {
                isError: true,
                content: [{ type: "text", text: result.stderr }],
            };
        }
        return {
          content: [{ type: "text", text: "File written successfully." }],
        };
      }
      case "ssh_list": {
        const result = await runSshCommand(`ls -F "${args.path}"`);
        if (result.code !== 0) {
            return {
                isError: true,
                content: [{ type: "text", text: result.stderr }],
            };
        }
        return {
          content: [{ type: "text", text: result.stdout }],
        };
      }
      default:
        throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${name}`);
    }
  } catch (error) {
    return {
      isError: true,
      content: [
        {
          type: "text",
          text: `SSH Error: ${error.message}`,
        },
      ],
    };
  }
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("SSH MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Fatal error in main():", error);
  process.exit(1);
});
