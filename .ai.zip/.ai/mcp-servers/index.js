import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ErrorCode,
  ListToolsRequestSchema,
  McpError,
} from "@modelcontextprotocol/sdk/types.js";
import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

const server = new Server(
  {
    name: "coolify-mcp-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

const API_URL = process.env.COOLIFY_API_URL || "https://coolify.stagings.website/api/v1";
const API_TOKEN = process.env.COOLIFY_API_TOKEN;

if (!API_TOKEN || API_TOKEN === "pon_tu_token_aqui") {
  console.error("Error: Configure COOLIFY_API_TOKEN in .env");
  process.exit(1);
}

const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    Authorization: `Bearer ${API_TOKEN}`,
    Accept: "application/json",
  },
});

server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "coolify_list_servers",
        description: "List all configured servers in Coolify.",
        inputSchema: { type: "object", properties: {} },
      },
      {
        name: "coolify_list_projects",
        description: "List all projects in Coolify.",
        inputSchema: { type: "object", properties: {} },
      },
      {
        name: "coolify_get_project_environments",
        description: "Get environments for a specific project.",
        inputSchema: {
          type: "object",
          properties: {
            projectUuid: { type: "string", description: "The UUID of the project" },
          },
          required: ["projectUuid"],
        },
      },
      {
        name: "coolify_custom_get_request",
        description: "Make a custom GET request to any Coolify API endpoint (e.g. /projects).",
        inputSchema: {
          type: "object",
          properties: {
            endpoint: { type: "string", description: "The API endpoint path, e.g., /projects or /servers" },
          },
          required: ["endpoint"],
        },
      },
      {
        name: "coolify_custom_post_request",
        description: "Make a custom POST request to any Coolify API endpoint.",
        inputSchema: {
          type: "object",
          properties: {
            endpoint: { type: "string", description: "The API endpoint path" },
            data: { type: "object", description: "The JSON payload to send" },
          },
          required: ["endpoint", "data"],
        },
      }
    ],
  };
});

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      case "coolify_list_servers": {
        const response = await apiClient.get("/servers");
        return {
          content: [{ type: "text", text: JSON.stringify(response.data, null, 2) }],
        };
      }
      case "coolify_list_projects": {
        const response = await apiClient.get("/projects");
        return {
          content: [{ type: "text", text: JSON.stringify(response.data, null, 2) }],
        };
      }
      case "coolify_get_project_environments": {
        const response = await apiClient.get(`/projects/${args.projectUuid}`);
        return {
          content: [{ type: "text", text: JSON.stringify(response.data, null, 2) }],
        };
      }
      case "coolify_custom_get_request": {
        const path = args.endpoint.startsWith("/") ? args.endpoint : `/${args.endpoint}`;
        const response = await apiClient.get(path);
        return {
          content: [{ type: "text", text: JSON.stringify(response.data, null, 2) }],
        };
      }
      case "coolify_custom_post_request": {
        const path = args.endpoint.startsWith("/") ? args.endpoint : `/${args.endpoint}`;
        const response = await apiClient.post(path, args.data);
        return {
          content: [{ type: "text", text: JSON.stringify(response.data, null, 2) }],
        };
      }
      default:
        throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${name}`);
    }
  } catch (error) {
    const errorData = error.response ? error.response.data : error.message;
    return {
      isError: true,
      content: [{ type: "text", text: `Coolify API Error: ${JSON.stringify(errorData)}` }],
    };
  }
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("Coolify MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Fatal error in main():", error);
  process.exit(1);
});
