# Active Context — Estado Vivo del Proyecto

> [!IMPORTANT]
> **REGLA DE LA IA:** Este archivo es la RAM del sistema. Se lee obligatoriamente al iniciar cada sesión ANTES de ejecutar cualquier tarea. Se actualiza obligatoriamente al cerrar cada sprint o feature completado. No es un log histórico: solo contiene el estado PRESENTE. Lo resuelto se elimina.

---

## 🗓️ Última Actualización

- **Fecha**: 2026-04-16
- **Sesión**: Construcción del Playbook IA del Workspace
- **Rol Activo**: `orchestrator-pm`

---

## 🎯 Objetivo del Sprint Actual

**Establecer el sistema normativo completo del workspace** (`.ai/`): todos los documentos de directrices, roles de sub-agentes y estándares técnicos que gobiernan cómo opera la IA en este proyecto.

---

## ✅ Logros Completados en Esta Sesión

- [x] `devops_sysadmin.md` — Analizado y ya existía con nivel de calidad alto (11 directrices).
- [x] `frontend_engineer.md` — Elevado de 4 puntos básicos a 11 directrices de excelencia premium (glassmorphism, GSAP, A11y, SEO semántico, bundle diet).
- [x] `qa_automation.md` — Elevado de 3 puntos a 11 directrices (pirámide de testing, contract testing, CWV, pipeline gate, SAST/DAST).
- [x] `seo_expert.md` — Creado desde cero con 10 directrices (on-page, OG tags, schema.org, Core Web Vitals, linkbuilding, GSC monitoring).
- [x] `orchestrator_pm.md` — Redefinido con 10 directrices operacionales (task breakdown, árbol de ruteo, protocolo de rol emergente, cierre de sprint, scope management).
- [x] `00_project_core.md` — Elevado de 3 secciones a 10 (jerarquía de autoridad, onboarding, principios universales DRY/KISS/YAGNI, política zero-trust, convenciones, DoD completa).
- [x] `01_planning_and_architecture.md` — Elevado de 3 secciones a 10 (PRD estándar, 3-path analysis, ADRs, patrones arquitectónicos, API-first, observabilidad).
- [x] `02_mcp_standards.md` — Elevado de 3 secciones a 10 (estructura `mcp/`, whitelist de seguridad, checklist de creación, ciclo de vida, prohibiciones absolutas).
- [x] `active_context.md` — Reestructurado con template completo y estado actual.

---

## 🏗️ Estado del Sistema de Roles

| Archivo                | Estado      | Directrices |
| ---------------------- | ----------- | ----------- |
| `orchestrator_pm.md`   | ✅ Completo | 10          |
| `backend_architect.md` | ✅ Completo | 11          |
| `devops_sysadmin.md`   | ✅ Completo | 11          |
| `frontend_engineer.md` | ✅ Completo | 11          |
| `qa_automation.md`     | ✅ Completo | 11          |
| `seo_expert.md`        | ✅ Completo | 10          |

---

## ⚠️ Errores Pendientes / Limitantes Conocidas

- Los MCPs físicos aún viven en `.ai/mcp-servers/`. El estándar define que deben migrar a `mcp/` en la raíz del proyecto. **Esta migración está pendiente.**
- El `mcp.json` aún apunta a las rutas antiguas (`.ai/mcp-servers/`). Requiere actualización al mover los MCPs.
- `backend_architect.md` fue analizado pero no fue complementado en esta sesión. Revisar si su nivel actual es consistente con los demás roles.

---

## 🔧 Deuda Técnica Identificada

| ID            | Descripción                                                             | Impacto si no se resuelve                                          | Prioridad |
| ------------- | ----------------------------------------------------------------------- | ------------------------------------------------------------------ | --------- |
| `[DEUDA-001]` | Migrar `ssh-mcp` y `coolify-mcp` de `.ai/mcp-servers/` a `mcp/` en raíz | `mcp.json` inconsistente con el estándar documentado               | Alta      |
| `[DEUDA-002]` | Actualizar `mcp.json` con nuevas rutas post-migración                   | Los MCPs dejan de funcionar si se mueven sin actualizar el config  | Alta      |
| `[DEUDA-003]` | Revisar `backend_architect.md` contra el nuevo estándar de calidad      | Inconsistencia de nivel entre roles del equipo                     | Media     |
| `[DEUDA-004]` | Crear `.env.example` para cada MCP existente si no existe               | Sin plantilla, el onboarding de nuevos entornos es manual y frágil | Media     |

---

## 📋 Próximos Pasos (Next Actions)

1. **Migrar MCPs a nueva estructura**: Mover `ssh-mcp/` y `coolify-mcp/` a `mcp/` en la raíz del proyecto.
2. **Actualizar `mcp.json`**: Reflejar las nuevas rutas absolutas post-migración.
3. **Revisar `backend_architect.md`**: Verificar nivel de detalle versus los demás roles y complementar si necesario.
4. **Crear `README.md` por MCP**: Cumplir el checklist de creación definido en `02_mcp_standards.md §5`.
5. **Primer uso en proyecto real**: Activar este playbook en un proyecto activo y validar que el flujo orquestador → sub-agente → cierre funciona como se diseñó.

---

## 📁 Mapa del Sistema `.ai/`

```
.ai/
├── 00_project_core.md              ← Ley Suprema del workspace
├── 01_planning_and_architecture.md ← PRD, ADRs, patrones
├── 02_mcp_standards.md             ← Estándares de herramientas MCP
├── active_context.md               ← Este archivo (RAM del sistema)
├── mcp.json                        ← Registro de MCPs activos [DESACTUALIZADO]
├── mcp-servers/                    ← [DEPRECATED] Mover contenido a /mcp/
│   ├── ssh-mcp/
│   └── coolify-mcp/
└── roles/
    ├── orchestrator_pm.md
    ├── backend_architect.md
    ├── devops_sysadmin.md
    ├── frontend_engineer.md
    ├── qa_automation.md
    └── seo_expert.md
```

---

## 📝 Retrospectiva de Esta Sesión

- ✅ **Qué funcionó bien**: El patrón de analizar primero → complementar después generó documentos coherentes y consistentes entre sí.
- ⚠️ **Fricción detectada**: La migración de MCPs a la nueva estructura `mcp/` no se ejecutó en esta sesión; quedó como deuda documentada.
- 🔧 **Ajuste para el próximo sprint**: Activar el playbook completo en un proyecto real para validar el flujo end-to-end antes de seguir añadiendo documentación teórica.
